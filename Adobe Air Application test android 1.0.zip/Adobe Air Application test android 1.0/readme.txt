Adobe Air Application test Android ver 1.0
------------------------------------------------
Copyright VanillaSnope 2024
------------------------------------------------
-->instructions<--
*Extract this folder and its contents.
*Install the apk file
*enjoy!
//note: this is not malware of any kind. Of course, that is exactly what a malware application would also say though, so use this app if you trust me. if not, then don't use it! Up to you.

https://ufo-yt.github.io/VanillaSnope/
VanillaSnope 2024